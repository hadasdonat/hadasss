using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);

// רישום Singleton של RecommendationService
builder.Services.AddSingleton<RecommendationService>();

var app = builder.Build();

// Serve static HTML file
app.UseDefaultFiles();
app.UseStaticFiles();

// Endpoint for processing genres
app.MapPost("/movies/genres", async ([FromServices] RecommendationService recommender, [FromBody] GenreRequest genreRequest) =>
{
    // בדיקה אם המידע תקין
    if (genreRequest == null || genreRequest.Genres == null)
    {
        return Results.BadRequest("Genres data is required.");
    }

    // הדפסה של הז'אנרים שהתקבלו
    Console.WriteLine("Debug: Genres received in /movies/genres: " + string.Join(", ", genreRequest.Genres));

    // בדיקה אם המשתמש לא בחר ז'אנרים
    if (!genreRequest.Genres.Any())
    {
        Console.WriteLine("Debug: No genres selected. Proceeding without genres.");
    }
    else if (genreRequest.Genres.Count > 5) // וידוא שלא נבחרו יותר מ-5
    {
        Console.WriteLine("Debug: More than 5 genres selected. Returning BadRequest.");
        return Results.BadRequest("You can select up to 5 genres only.");
    }

    // שמירת הז'אנרים
    await recommender.SaveGenres(genreRequest.Genres);
    Console.WriteLine("Debug: Genres saved successfully.");

    return Results.Ok(new { Message = "Genres processed successfully." });
});

app.MapPost("/movies/recommendations", async ([FromServices] RecommendationService recommender, [FromForm] IFormFile image) =>
{
    if (image == null || image.Length == 0)
    {
        Console.WriteLine("Debug: No image uploaded.");
        return Results.BadRequest("Image is required.");
    }

    try
    {
        // Save the image temporarily (for processing purposes)
        var filePath = Path.GetTempFileName();
        Console.WriteLine("Debug: Image saved temporarily at " + filePath);

        using (var stream = new FileStream(filePath, FileMode.Create))
        {
            await image.CopyToAsync(stream);
        }

        // בדיקת ז'אנרים שמורים
        var genres = recommender.GetSavedGenres();
        Console.WriteLine("Debug: Genres used in /movies/recommendations: " + (genres.Any() ? string.Join(", ", genres) : "No genres"));

        if (genres == null || !genres.Any())
        {
            Console.WriteLine("Debug: No genres provided. Proceeding with emotion-based recommendations only.");
        }

        var recommendedMovies = await recommender.GetRecommendedMovies(filePath, genres ?? new List<string>());


        // Clean up temporary file
        File.Delete(filePath);
        Console.WriteLine("Debug: Temporary image file deleted.");
        Console.WriteLine($"Debug: recommendedMovies - {recommendedMovies}");

        return Results.Ok(recommendedMovies);
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Debug: Exception occurred - {ex.Message}");
        return Results.Problem(ex.Message);
    }
});

app.Run();